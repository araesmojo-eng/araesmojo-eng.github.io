#version 330 core
out vec4 FragColor;

in vec2 TexCoord;
in float glLayer;

struct Material {
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
    vec3 roughness;

    sampler2D diffTex;
    sampler2D ambtTex;
    sampler2D specTex;
    sampler2D normTex;
    sampler2D dispTex;
    sampler2D rghnTex;
};

uniform Material mtrl[2];
uniform int pt_light;

uniform sampler2DArray shadowMapPara;

void main()
{
    if( texture( mtrl[0].diffTex, TexCoord ).a < 0.05 ){
        discard;
    } else {
        float xCrd = ( gl_FragCoord.x - 512.0 ) / 512.0;
        float yCrd = ( gl_FragCoord.y - 512.0 ) / 512.0;
        if( ( xCrd * xCrd + yCrd * yCrd ) > 1.0 ){
            discard;
        } else {
            float depth  = gl_FragCoord.z;
            float staticDepth = texture( shadowMapPara, vec3( xCrd, yCrd, glLayer ) )[pt_light];
            if( depth < staticDepth ){
                // write this as modified depth
                FragColor    = vec4( depth, depth, depth, depth );
                gl_FragDepth = depth;
            }
        }
    }
}