#version 330 core
out vec4 FragColor;

in vec3 TexCoords;

uniform samplerCube skyboxTex;
uniform samplerCube shadowMapCube[4];
uniform samplerCube shadowMapCubeColors;
uniform samplerCube shadowMapCubeColorsMove;
uniform samplerCube envMapCube;

uniform int cubeIndex;
uniform int skybox_lod;

void main(){
    if( cubeIndex == 0 ){
        FragColor = textureLod( skyboxTex, TexCoords, skybox_lod );
    } else if( cubeIndex == 1 ){
        vec3 envColor = textureLod( envMapCube, TexCoords, skybox_lod ).rgb;
        envColor      = envColor / ( envColor + vec3(1.0) );
        envColor      = pow( envColor, vec3(1.0/2.2) ); 
    
        FragColor = vec4(envColor, 1.0);
    } else if( cubeIndex == 2 ){
        FragColor = texture( shadowMapCube[0], TexCoords );
    } else if( cubeIndex == 3 ){
        FragColor = texture( shadowMapCube[1], TexCoords );
    } else if( cubeIndex == 4 ){
        FragColor = texture( shadowMapCube[2], TexCoords );
    } else if( cubeIndex == 5 ){
        FragColor = texture( shadowMapCube[3], TexCoords );
    } else if( cubeIndex == 6 ){
        FragColor = texture( shadowMapCubeColors, TexCoords );
    } else if( cubeIndex == 7 ){
        FragColor = texture( shadowMapCubeColorsMove, TexCoords );
    }
    //} else if( cubeIndex == 1 ){
    //    FragColor = texture( shadowMapCubeStatic, TexCoords );
    //} else if( cubeIndex == 2 ){
    //    FragColor = texture( shadowMapCubeMove, TexCoords );
    //} else if( cubeIndex == 3 ){
    //    vec3 envColor = textureLod( envMapCube, TexCoords, skybox_lod ).rgb;
    //    envColor      = envColor / ( envColor + vec3(1.0) );
    //    envColor      = pow( envColor, vec3(1.0/2.2) ); 
    //
    //    FragColor = vec4(envColor, 1.0);
    //}
}