#version 330 core
out vec4 FragColor;

in vec2 TexCoord;

struct Material {
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
    vec3 roughness;

    sampler2D diffTex;
    sampler2D ambtTex;
    sampler2D specTex;
    sampler2D normTex;
    sampler2D dispTex;
    sampler2D rghnTex;
};

uniform Material mtrl[2];

void main()
{
    if( texture( mtrl[0].diffTex, TexCoord ).a < 0.05 ){
        discard;
    } else {
        FragColor    = vec4( gl_FragCoord.z, gl_FragCoord.z, gl_FragCoord.z, gl_FragCoord.z );
        gl_FragDepth = gl_FragCoord.z;
    }
}