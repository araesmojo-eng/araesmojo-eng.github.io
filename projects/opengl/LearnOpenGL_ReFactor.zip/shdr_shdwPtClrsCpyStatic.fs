#version 330 core
layout (location = 0) out vec4 FragColor;
in vec3 PosWrld;

uniform samplerCube shadowMapCubeStatic;

void main(){		
    FragColor    = texture( shadowMapCubeStatic, PosWrld );
    //gl_FragDepth = texture( shadowMapCubeDepthStatic, PosWrld ).r;
}