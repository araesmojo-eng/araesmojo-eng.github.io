#version 330 core

out vec4 FragColor;

in vec2 TexCoordStart;

uniform sampler2D diffuse;
uniform vec2 texCoordScale;

void main(){
    FragColor = texture( diffuse, ( TexCoordStart + gl_PointCoord * texCoordScale ) );
}