#version 330 core
out vec3 FragColor;
in vec3 PosWrld;

uniform sampler2D equirectangularMap;

void main(){		
    vec3 pos_n  = normalize( PosWrld );
    float theta = atan( pos_n.z, pos_n.x );
    float phi   = asin( pos_n.y );
    vec2 uv = vec2( ( theta + 3.141592654 ) / 6.283185307, (phi + 1.570796327) / 3.141592654 );
    vec3 color = texture( equirectangularMap, uv ).rgb;

    FragColor = color;
}