#version 330 core
out vec4 FragColor;

in vec2 TexCoord;
in float glLayer;

uniform sampler2DArray shadowMapPara;

void main()
{
    FragColor = texture( shadowMapPara, vec3( TexCoord, glLayer ) );
    //FragColor = vec4( TexCoord, glLayer, 1.0 );
}