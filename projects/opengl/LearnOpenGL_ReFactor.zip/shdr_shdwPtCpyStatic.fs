#version 330 core
layout (location = 0) out float FragColor0;
layout (location = 1) out float FragColor1;
layout (location = 2) out float FragColor2;
layout (location = 3) out float FragColor3;
in vec3 PosWrld;

uniform samplerCube shadowMapCube[4];

void main(){		
    FragColor0 = texture( shadowMapCube[0], PosWrld ).r;		
    FragColor1 = texture( shadowMapCube[1], PosWrld ).r;		
    FragColor2 = texture( shadowMapCube[2], PosWrld ).r;		
    FragColor3 = texture( shadowMapCube[3], PosWrld ).r;
}