#version 330 core
out vec4 FragColor;

in vec3 TexCoords;

uniform samplerCube skyboxTex;

uniform samplerCube shadowMapCube[4];

uniform int cubeIndex;

void main(){
    if( cubeIndex == 0 ){
        FragColor = texture( skyboxTex, TexCoords );
    } else {
        float depth = texture( shadowMapCube[cubeIndex-1], TexCoords ).r;
        FragColor = vec4( depth, depth, depth, 1.0 );
    }
}