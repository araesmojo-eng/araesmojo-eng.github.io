#version 330 core
layout(location = 0) out vec4 FragColor0;

in vec2 TexCoords;

uniform sampler2D screenTexture;

uniform int postProcessingMode = 0;
uniform bool isSecondStep = false;

uniform vec2 offsets_3x3[9];
uniform vec2 offsets_5x5[25];
uniform float offsets_1D_7x7[7];
uniform float offsets_1D_9x9[9];

uniform float kernel_3x3[9];
uniform float kernel_5x5[25];
uniform float kernel_1D_9x9[9];

void main(){
    vec3 color = texture( screenTexture, TexCoords ).rgb;
    if( postProcessingMode == 0 ){
        FragColor0 = vec4( color, 1.0 );
    } else if( postProcessingMode == 1 ){  // Color Inversion
        FragColor0 = vec4( vec3( 1.0 - color ), 1.0 );
    } else if( postProcessingMode == 2 ){  // Color Grayscale
        float average = 0.2126 * color.r + 0.7152 * color.g + 0.0722 * color.b;
        FragColor0     = vec4( average, average, average, 1.0 );
    } else if( postProcessingMode == 3 ){  
        vec3 color = vec3(0.0);
        for( int i = 0; i < 9; i++ ){
            color += vec3( texture( screenTexture, TexCoords.xy + offsets_3x3[i].xy ) ) * kernel_3x3[i];
        }
        FragColor0 = vec4( color, 1.0 );
    } else if( postProcessingMode == 4 ){
        vec3 color = vec3(0.0);
        for( int i = 0; i < 25; i++ ){
            color += vec3( texture( screenTexture, TexCoords.xy + offsets_5x5[i].xy ) ) * kernel_5x5[i];
        }
        FragColor0 = vec4( color, 1.0 );
    } else if( postProcessingMode == 5 ){
        vec3 color = vec3(0.0);
        if( !isSecondStep ){  // Apply horizontal kernel
            for( int i = 0; i < 9; i++ ){
                color += vec3( texture( screenTexture, TexCoords.xy + vec2( offsets_1D_9x9[i], 0.0 ) ) ) * kernel_1D_9x9[i];
            }
        } else {  // Apply vertical kernel
            for( int i = 0; i < 9; i++ ){
                color += vec3( texture( screenTexture, TexCoords.xy + vec2( 0.0, offsets_1D_9x9[i] ) ) ) * kernel_1D_9x9[i];
            }
        }
        FragColor0 = vec4( color, 1.0 );
    }
}