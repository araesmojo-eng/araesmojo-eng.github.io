#version 330 core
in vec4 FragPos;

uniform vec3 light_pos;
uniform float far_plane;
uniform float near_plane;

void main()
{
    float lightDistance = length(FragPos.xyz - light_pos);
    
    // map to [0;1] range by dividing by far_plane
    lightDistance = lightDistance / far_plane;
    
    // write this as modified depth
    gl_FragDepth = lightDistance;
    //gl_FragDepth = sqrt( (2.0 * 0.1 ) / (far_plane + 0.1 - ( lightDistance  * 2.0 - 1.0 ) * (far_plane - 0.1)) );
    //float z     = lightDistance + lightDistance - 1.0; // back to NDC 
    //float depth = ( near_plane + near_plane ) / (far_plane + near_plane - z * (far_plane - near_plane));
}

