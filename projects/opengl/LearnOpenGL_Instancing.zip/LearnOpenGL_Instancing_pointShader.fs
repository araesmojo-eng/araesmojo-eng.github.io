#version 330 core

out vec4 FragColor;

in vec2 gsTexCoordStart;
in vec2 gsTexCoordScale;

uniform sampler2D diffuse;

void main(){
    //FragColor = vec4(gl_PointCoord.x, gl_PointCoord.y, 0.0, 1.0);
    //FragColor = texture( diffuse, ( gl_PointCoord ) );
    FragColor = texture( diffuse, ( gsTexCoordStart + gl_PointCoord * gsTexCoordScale ) );
}