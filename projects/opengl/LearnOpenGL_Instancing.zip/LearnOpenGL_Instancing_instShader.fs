#version 330 core
out vec4 FragColor;

in vec2 TexCoords;

struct MaterialTexture {
    sampler2D diffuse;
    sampler2D ambient;
    sampler2D specular;
    sampler2D normal;
};

uniform MaterialTexture mtrlTex1;

void main()
{
    FragColor = texture( mtrlTex1.diffuse, TexCoords );
}