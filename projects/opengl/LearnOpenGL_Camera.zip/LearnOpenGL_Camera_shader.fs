#version 330 core
out vec4 FragColor;

in vec3 vertexShaderOutColor;
in vec2 TexCoord;

// texture samplers
uniform sampler2D texture1;
uniform sampler2D texture2;

// rendering type
uniform int renderingType;

void main()
{
    // First implementation of the example using only the first texture
    if( renderingType < 2 ){
        FragColor = texture(texture1, TexCoord);
    } else {
        if( renderingType == 2 ){
            FragColor = texture(texture1, TexCoord) * vec4(vertexShaderOutColor, 1.0);
        } else {
            FragColor = mix(texture(texture1, TexCoord), texture(texture2, TexCoord), 0.5);
        }
    }

    // Second implementation of the example using texture and color inputs
    //FragColor = texture(texture1, TexCoord) * vec4(vertexShaderOutColor, 1.0);

	// Third implmentation of the example linearly interpolating between both textures (80% tex1, 20% tex2)
	//FragColor = mix(texture(texture1, TexCoord), texture(texture2, TexCoord), 0.5);
}