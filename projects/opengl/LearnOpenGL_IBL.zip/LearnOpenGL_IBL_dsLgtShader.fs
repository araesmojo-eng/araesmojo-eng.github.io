#version 330 core
out vec4 FragColor;

//in vec2 TexCoords;

uniform sampler2D dsbPositionTex;
uniform sampler2D dsbNormalTex;
uniform sampler2D dsbAlbedoSpecTex;

struct Light {
    int  type;  // 0 ambient, 1 directional, 2 point, 3 spot, 4 point_atn, 5 spot_atn
    vec3 direction;
    vec3 position;

    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
	
    float atn_cnst;
    float atn_lin;
    float atn_quad;
    
    float cutoffInner;
    float cutOffSt;
    float cutOff;
    float FOV;

    float farClipSq;
};

const int MAX_LIGHTS = 8;
uniform int light_count;
uniform Light light[MAX_LIGHTS];
uniform bool isBlinnPhong;
uniform mat4 view_proj_light[2];  // projection * view, light source perspective

uniform sampler2D shadowMap;
uniform samplerCube shadowMapCubeStatic;
uniform samplerCube shadowMapCubeMove;

uniform vec3 viewPos;
uniform int dsLgtOut;

uniform vec2 screenSizePix;

void calc_light_dir_and_atn( out vec3 lightDir, out float atn_amb, out float atn_ds, vec3 frag_pos, Light light ){
    lightDir = vec3( 0.0, -1.0, 0.0 );
    atn_amb  = 1.0f;
    atn_ds   = 1.0f;

    float amb_intensity  = 1.0f;
    float spot_intensity = 1.0f;

    if( light.type == 0 ){
        atn_ds   = 0.0f;
    } else if( light.type == 1 ){
        lightDir = light.direction;  // lightDir and light.direction only equal because the directional light has no distance component
        lightDir = normalize( lightDir );
    } else {
        lightDir = frag_pos - light.position;
        float distSq = lightDir.x * lightDir.x + lightDir.y * lightDir.y + lightDir.z * lightDir.z;
        if( distSq <= light.farClipSq ){
            float distance = sqrt( distSq );
            vec3 lightDir_norm = lightDir / distance;
            if( light.type > 3 ){
                // distance based attenuation
                atn_amb        = 1.0 / ( light.atn_cnst + ( light.atn_lin + ( light.atn_quad * distance ) ) * distance );
                atn_ds         = atn_amb;
            }

            if( light.type == 3 || light.type == 5 ){
                // spotlight (soft edges)
                // The lightDir_norm is the position relative to the vsFragPos while the light[0].direction is the pointing direction
                float theta    = dot( -lightDir_norm, normalize( -light.direction ) );
                spot_intensity = clamp( ( theta - light.cutOff ) / ( light.cutOffSt - light.cutOff ), 0.0, 1.0 );
                amb_intensity  = clamp( ( theta - light.FOV    ) / ( light.cutOffSt - light.FOV    ), 0.0, 1.0 );
                atn_ds  *= spot_intensity;
                atn_amb *= amb_intensity;
            }
            lightDir = lightDir_norm;
        } else {
            atn_amb = 0.0;
            atn_ds  = 0.0;
        }
    }
}

void calc_ambient( out vec3 ambient_out, vec3 light, vec3 material ){
    ambient_out = light * material;
}

void calc_diffuse( out vec3 diffuse_out, vec3 normal, vec3 pixel_pos, vec3 light_dir, vec3 light, vec3 material ){
    float diff  = max( dot( normal, -light_dir ), 0.0 );
    diffuse_out = light * diff * material;
}

void calc_specular( out vec3 specular_out, vec3 normal, vec3 view_dir, vec3 light_dir, vec3 light, vec3 material, float shiny ){
    float viewedReflect;
    if( isBlinnPhong ){
        vec3 halfwayDir = normalize( view_dir - light_dir );  
        viewedReflect   = max( dot( normal, halfwayDir ), 0.0 );
    } else {
        vec3 reflectDir = reflect( light_dir, normal );
        viewedReflect   = max( dot( view_dir, reflectDir ), 0.0 );
    }
    float spec          = pow( viewedReflect, shiny );
    specular_out        = light * spec * material;
}

float ShadowCalculation( vec4 fragPosSrcLgtVP, int shdwNmb ){
    // perform perspective divide
    vec3 projCoords = fragPosSrcLgtVP.xyz / fragPosSrcLgtVP.w;
    // transform to [0,1] range
    projCoords = projCoords * 0.5 + 0.5;

    float shadow = 0.0;  // keep the shadow at 0.0 when outside the far_plane region of the light's frustum.
    if( projCoords.z <= 1.0 ){
        // get closest depth value from light's perspective (using [0,1] range fragPosLight as coords)
        float closestDepth = texture(shadowMap, projCoords.xy)[shdwNmb]; 
        // get depth of current fragment from light's perspective
        float currentDepth = projCoords.z;
        
        float bias = 0.002;
        float cdmb = (currentDepth - bias);
        shadow = cdmb > closestDepth  ? 1.0 : 0.0;
    }
    
    return shadow;
}

float ShadowCalculationCubemap( vec3 fragPos, Light light, int lgt ){
    // get vector between fragment position and light position
    vec3 fragToLight = fragPos - light.position;
    // use the light to fragment vector to sample from the depth map
    //float closestDepth = texture( shadowMapCubeColor[lgt-2], fragToLight ).r;
    float closestDepth = texture( shadowMapCubeMove, fragToLight )[lgt];
    // it is currently in linear range between [0,1]. Re-transform back to original value
    //closestDepth *= far_plane;
    closestDepth *= sqrt(light.farClipSq);
    //closestDepth *= 100.0;
    // now get current linear depth as the length between the fragment and light position
    float currentDepth = length( fragToLight );
    //float currentDepth = (fragToLight.x * fragToLight.x + fragToLight.y * fragToLight.y + fragToLight.z * fragToLight.z);
    // now test for shadows
    float offset = 0.040;
    float shadow = (currentDepth - offset) > closestDepth ? 1.0 : 0.0;
    //float shadow = currentDepth > closestDepth ? 1.0 : 0.0;

    return shadow;
}

void main(){        
    vec2 TexCoords = gl_FragCoord.xy / screenSizePix;
    // retrieve data from gbuffer
    vec3 dsbFragPos   = texture(dsbPositionTex,   TexCoords).rgb;
    vec3 dsbNormal    = texture(dsbNormalTex,     TexCoords).rgb;
    vec3 dsbDiffuse   = texture(dsbAlbedoSpecTex, TexCoords).rgb;
    vec3 dsbSpecular  = vec3(texture(dsbAlbedoSpecTex, TexCoords).a);
    
    if( dsLgtOut == 0 ){
        // then calculate lighting as usual
        vec3 result  = vec3(0.0);
        vec3 viewDir = normalize(viewPos - dsbFragPos);
        vec3 lightDir, ambient, diffuse, specular;
        float atn_amb, atn_ds;

        if( light[light_count].type == 1 ){
            calc_light_dir_and_atn( lightDir, atn_amb, atn_ds, dsbFragPos, light[light_count] );
            calc_ambient( ambient, light[light_count].ambient, vec3(0.1) );
            calc_diffuse(  diffuse,  dsbNormal, dsbFragPos, lightDir, light[light_count].diffuse,  dsbDiffuse );
            calc_specular( specular, dsbNormal, viewDir,    lightDir, light[light_count].specular, dsbSpecular, 16.0 );
            FragColor = vec4( ambient * atn_amb + ( diffuse + specular ) * atn_ds, 1.0 );
        } else if( light[light_count].type == 4 ){
            calc_light_dir_and_atn( lightDir, atn_amb, atn_ds, dsbFragPos, light[light_count] );

            float shadow = ShadowCalculationCubemap( dsbFragPos, light[light_count], light_count-3 );
            atn_ds *= ( 1.0 - shadow );

            calc_ambient( ambient, light[light_count].ambient, vec3(0.1) );
            if( atn_ds > 0.0 ){
                calc_diffuse(  diffuse,  dsbNormal, dsbFragPos, lightDir, light[light_count].diffuse,  dsbDiffuse );
                calc_specular( specular, dsbNormal, viewDir,    lightDir, light[light_count].specular, dsbSpecular, 16.0 );
            }
            FragColor = vec4( ambient * atn_amb + ( diffuse + specular ) * atn_ds, 1.0 );
        } else if( light[light_count].type == 5 ){
            calc_light_dir_and_atn( lightDir, atn_amb, atn_ds, dsbFragPos, light[light_count] );

            int shdwNmb = 0;
            if( light_count == 2 ){ shdwNmb = 1; }
            float shadow = ShadowCalculation( view_proj_light[shdwNmb] * vec4( dsbFragPos, 1.0 ), shdwNmb );
            atn_ds *= ( 1.0 - shadow );

            calc_ambient( ambient, light[light_count].ambient, vec3(0.1) );
            if( atn_ds > 0.0 ){
                calc_diffuse(  diffuse,  dsbNormal, dsbFragPos, lightDir, light[light_count].diffuse,  dsbDiffuse );
                calc_specular( specular, dsbNormal, viewDir,    lightDir, light[light_count].specular, dsbSpecular, 16.0 );
            }
            FragColor = vec4( ambient * atn_amb + ( diffuse + specular ) * atn_ds, 1.0 );
        }
    } else if( dsLgtOut == 1 ){
        FragColor   = vec4( dsbFragPos, 1.0 );
    } else if( dsLgtOut == 2 ){
        FragColor   = vec4( dsbNormal, 1.0 );
    } else if( dsLgtOut == 3 ){
        FragColor   = vec4( dsbDiffuse, 1.0 );
    } else {
        FragColor   = vec4( dsbSpecular, 1.0 );
    }
}