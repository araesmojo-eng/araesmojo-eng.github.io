#version 330 core
layout (location = 0) out vec4 FragColor;
in vec3 WorldPos;

uniform samplerCube shadowMapCubeStatic;

void main(){		
    FragColor    = texture( shadowMapCubeStatic, WorldPos );
    //gl_FragDepth = texture( shadowMapCubeDepthStatic, WorldPos ).r;
}