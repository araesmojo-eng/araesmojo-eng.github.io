#version 330 core
out vec4 FragColor;

//flat in int lightNmb;

void main()
{
    //FragColor = vec4( 1.0, 1.0, 1.0, 1.0 );
    //FragColor[lightNmb] = gl_FragCoord.z;
    FragColor    = vec4( gl_FragCoord.z, gl_FragCoord.z, gl_FragCoord.z, gl_FragCoord.z );

    gl_FragDepth = gl_FragCoord.z;
}